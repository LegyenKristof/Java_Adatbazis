package org.example.adatbazismasik;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class Adatbazis {
    private Connection conn;

    private static final String url = "jdbc:mysql://localhost:3306/dolgozok";
    private static final String username = "root";
    private static final String password = "";

    public Adatbazis() throws SQLException {
        conn = DriverManager.getConnection(url, username, password);
    }

    public List<Dolgozo> dolgozokListazasa() throws SQLException{
        List<Dolgozo> dolgozoLista = new ArrayList<>();
        String sql = "SELECT * FROM dolgozok";
        Statement stmt = conn.createStatement();
        ResultSet result = stmt.executeQuery(sql);
        while (result.next()){
            Dolgozo dolgozo = new Dolgozo(
                    result.getInt("id"),
                    result.getInt("kor"),
                    result.getInt("fizetes"),
                    result.getString("nev"),
                    result.getString("nem")
            );
            System.out.println(dolgozo);
            dolgozoLista.add(dolgozo);
        }
        return dolgozoLista;
    }
}
