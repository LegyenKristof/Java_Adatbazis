package org.example.adatbazismasik;

public class Main {

    public static void main(String[] args) throws Exception{
        Adatbazis adatbazis = new Adatbazis();
        adatbazis.dolgozokListazasa();
    }
}
