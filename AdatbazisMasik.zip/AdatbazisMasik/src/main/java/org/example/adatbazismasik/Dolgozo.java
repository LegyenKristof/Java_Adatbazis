package org.example.adatbazismasik;

public class Dolgozo {
    private int id, kor, fizetes;
    private String nev, nem;

    public Dolgozo(int id, int kor, int fizetes, String nev, String nem) {
        this.id = id;
        this.kor = kor;
        this.fizetes = fizetes;
        this.nev = nev;
        this.nem = nem;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getKor() {
        return kor;
    }

    public void setKor(int kor) {
        this.kor = kor;
    }

    public int getFizetes() {
        return fizetes;
    }

    public void setFizetes(int fizetes) {
        this.fizetes = fizetes;
    }

    public String getNev() {
        return nev;
    }

    public void setNev(String nev) {
        this.nev = nev;
    }

    public String getNem() {
        return nem;
    }

    public void setNem(String nem) {
        this.nem = nem;
    }

    @Override
    public String toString() {
        return String.format("%d. Név: %s, Nem: %s, Kor: %d, Fizetés: %d", id, nev, nem, kor, fizetes);
    }
}
